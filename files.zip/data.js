// ============================================================
// PORTLAND TRIP SURVEY — DATA / STATE MODULE
// All localStorage reads/writes go through here.
// Keys: "portland_responses_jessica", "portland_responses_libby"
//       "portland_admin_pin"
// ============================================================

const DATA = {

  // ── Keys ──────────────────────────────────────────────────
  keys: {
    jessica: "portland_responses_jessica",
    libby:   "portland_responses_libby",
    pin:     "portland_admin_pin"
  },

  // ── Load all responses for a guest ───────────────────────
  // Returns object: { w1q1: "yes", w1q2: "no", w2q3: 4, ... }
  load(guestId) {
    try {
      const raw = localStorage.getItem(this.keys[guestId]);
      return raw ? JSON.parse(raw) : {};
    } catch {
      return {};
    }
  },

  // ── Save a single answer ──────────────────────────────────
  save(guestId, questionId, value) {
    const data = this.load(guestId);
    data[questionId] = value;
    localStorage.setItem(this.keys[guestId], JSON.stringify(data));
  },

  // ── Save a full week at once ──────────────────────────────
  saveWeek(guestId, answers) {
    const data = this.load(guestId);
    Object.assign(data, answers);
    localStorage.setItem(this.keys[guestId], JSON.stringify(data));
  },

  // ── Get completed weeks for a guest ──────────────────────
  completedWeeks(guestId) {
    const data = this.load(guestId);
    const completed = [];
    for (let w = 1; w <= 11; w++) {
      const weekQs = QUESTIONS.find(wk => wk.week === w);
      if (!weekQs) continue;
      // A week is "complete" if all non-text questions have answers
      const required = weekQs.questions.filter(q => q.type !== "text");
      const allAnswered = required.every(q => data[q.id] !== undefined);
      if (allAnswered) completed.push(w);
    }
    return completed;
  },

  // ── Get "in the running" places (yesno_place answers = yes) ──
  getYesPlaces(guestId) {
    const data = this.load(guestId);
    const places = [];
    for (const week of QUESTIONS) {
      for (const q of week.questions) {
        if (q.type === "yesno_place" && data[q.id] === "yes") {
          places.push({ ...q.place, week: week.week, questionId: q.id });
        }
      }
    }
    return places;
  },

  // ── Get combined yes places (both guests) ────────────────
  getCombinedYesPlaces() {
    const jPlaces = this.getYesPlaces("jessica");
    const lPlaces = this.getYesPlaces("libby");
    // Merge: a place is "in the running" if either said yes
    const allIds = new Set([
      ...jPlaces.map(p => p.questionId),
      ...lPlaces.map(p => p.questionId)
    ]);
    const combined = [];
    for (const qId of allIds) {
      const jp = jPlaces.find(p => p.questionId === qId);
      const lp = lPlaces.find(p => p.questionId === qId);
      const place = jp || lp;
      combined.push({
        ...place,
        jessicaVote: jPlaces.some(p => p.questionId === qId) ? "yes" : (this.load("jessica")[qId] === "no" ? "no" : "—"),
        libbyVote:   lPlaces.some(p => p.questionId === qId) ? "yes" : (this.load("libby")[qId]   === "no" ? "no" : "—"),
        bothYes: jp && lp
      });
    }
    return combined.sort((a, b) => b.bothYes - a.bothYes);
  },

  // ── Pin management ───────────────────────────────────────
  getPin() {
    return localStorage.getItem(this.keys.pin);
  },
  setPin(pin) {
    localStorage.setItem(this.keys.pin, pin);
  },
  checkPin(pin) {
    return localStorage.getItem(this.keys.pin) === pin;
  },

  // ── Export to Google Sheets paste format ─────────────────
  exportForSheets() {
    const jessica = this.load("jessica");
    const libby   = this.load("libby");
    const rows = ["Question ID\tQuestion Text\tJessica\tLibby"];
    for (const week of QUESTIONS) {
      for (const q of week.questions) {
        const jAns = jessica[q.id] !== undefined ? String(jessica[q.id]) : "";
        const lAns = libby[q.id]   !== undefined ? String(libby[q.id])   : "";
        const text = q.text.replace(/\t/g, " ").substring(0, 80);
        rows.push(`${q.id}\t${text}\t${jAns}\t${lAns}`);
      }
    }
    return rows.join("\n");
  },

  // ── Get current active week (based on today's date) ──────
  getCurrentWeek() {
    const today = new Date();
    for (let i = WEEK_SCHEDULE.length - 1; i >= 0; i--) {
      const send = new Date(WEEK_SCHEDULE[i].sendDate);
      if (today >= send) return WEEK_SCHEDULE[i].week;
    }
    return 1;
  }

};
