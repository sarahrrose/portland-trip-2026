// ============================================================
// PORTLAND TRIP SURVEY — QUESTION BANK
// 11 weeks of progressive questions, front-loading big travel
// decisions so driving/distance preferences are known early.
// Each week builds on previous answers.
// ============================================================

const QUESTIONS = [

  // ── WEEK 1 ── Big Attractions & Travel Appetite ──────────
  {
    week: 1,
    theme: "The Big Adventures",
    intro: "Let's start with the big stuff — the Pacific Northwest has some legendary spots within a few hours of Portland. No pressure, just gut reactions!",
    questions: [
      {
        id: "w1q1",
        type: "scale",
        text: "How do you feel about road trips during a vacation? (1 = I'd rather stay close to the city, 5 = I love a good drive to somewhere epic)",
        scale: { min: 1, max: 5, labels: ["Stay in the city", "Love a long drive"] }
      },
      {
        id: "w1q2",
        type: "yesno_place",
        text: "Multnomah Falls is one of the tallest waterfalls in the US — it's about 30 minutes from Portland and involves a short hike up to the viewpoint. Does that sound like your kind of thing?",
        place: { name: "Multnomah Falls", category: "nature", icon: "💧" }
      },
      {
        id: "w1q3",
        type: "yesno_place",
        text: "Timberline Lodge on Mt. Hood is a stunning 1930s mountain lodge — and fun fact, it was the exterior used in The Shining. It's about 90 minutes away. Worth the drive?",
        place: { name: "Timberline Lodge (Mt. Hood)", category: "landmark", icon: "🏔️" }
      },
      {
        id: "w1q4",
        type: "yesno_place",
        text: "The Oregon Coast is about 2 hours away — dramatic cliffs, sea stacks, and fresh Dungeness crab. Astoria, at the north end, is where The Goonies was filmed. Is a coast day calling your name?",
        place: { name: "Oregon Coast / Astoria", category: "nature", icon: "🌊" }
      },
      {
        id: "w1q5",
        type: "yesno_place",
        text: "Hood River is a cute little town about an hour east — windsurfers, a great food scene, and a brewery or two with views of Mt. Hood. Does that sound like a fun afternoon?",
        place: { name: "Hood River", category: "day_trip", icon: "🍺" }
      }
    ]
  },

  // ── WEEK 2 ── Portland Neighborhoods & Vibe ───────────────
  {
    week: 2,
    theme: "Portland's Personality",
    intro: "Portland is made up of really distinct neighborhoods — some quirky, some foodie, some outdoorsy. Let's figure out which ones fit you.",
    questions: [
      {
        id: "w2q1",
        type: "yesno_place",
        text: "Powell's City of Books is the world's largest independent bookstore — it takes up an entire city block. Even if you're not a huge reader, it's a Portland institution. Worth a wander?",
        place: { name: "Powell's City of Books", category: "culture", icon: "📚" }
      },
      {
        id: "w2q2",
        type: "yesno_place",
        text: "Voodoo Doughnut is famous for wild flavors and a line out the door. The bacon maple bar is legendary. Are you a yes on quirky donuts?",
        place: { name: "Voodoo Doughnut", category: "food", icon: "🍩" }
      },
      {
        id: "w2q3",
        type: "yesno_place",
        text: "Portland Saturday Market is the largest continuously operating outdoor arts & crafts market in the US. Local makers, food stalls, street performers — does that sound fun?",
        place: { name: "Portland Saturday Market", category: "shopping", icon: "🛍️" }
      },
      {
        id: "w2q4",
        type: "scale",
        text: "How much do you like exploring on foot with no fixed plan? (1 = I like knowing what's next, 5 = Let's just wander and see what happens)",
        scale: { min: 1, max: 5, labels: ["Give me a plan", "Let's wander"] }
      },
      {
        id: "w2q5",
        type: "choice",
        text: "Which Portland neighborhood vibe sounds most like you?",
        options: [
          { value: "pearl", label: "Pearl District — upscale galleries, great restaurants, walkable" },
          { value: "alberta", label: "Alberta Arts District — eclectic, murals, funky shops" },
          { value: "hawthorne", label: "Hawthorne — indie bookstores, vintage clothing, chill cafes" },
          { value: "nob_hill", label: "Nob Hill / 23rd Ave — charming Victorian streets, good food" }
        ]
      }
    ]
  },

  // ── WEEK 3 ── Food Preferences ────────────────────────────
  {
    week: 3,
    theme: "Let's Talk Food",
    intro: "Portland has an incredible food scene — from James Beard-nominated restaurants to legendary food cart pods. Let's dial in what sounds good to you.",
    questions: [
      {
        id: "w3q1",
        type: "multiselect",
        text: "Which of these food styles gets you most excited? (Pick all that apply)",
        options: [
          { value: "seafood", label: "Pacific Northwest seafood (salmon, Dungeness crab, oysters)" },
          { value: "farm_to_table", label: "Farm-to-table / seasonal menus" },
          { value: "international", label: "International street food / food carts" },
          { value: "bbq", label: "Smoked meats / BBQ" },
          { value: "veg", label: "Plant-forward / vegetarian-friendly" },
          { value: "comfort", label: "Elevated comfort food (burgers, fried chicken done right)" }
        ]
      },
      {
        id: "w3q2",
        type: "yesno_place",
        text: "Tasty n Daughters is a Portland brunch legend — think Middle Eastern spiced eggs, creative cocktails, and a cozy Southeast Portland room. Brunch scene: are you in?",
        place: { name: "Tasty n Daughters", category: "restaurant", icon: "🍳" }
      },
      {
        id: "w3q3",
        type: "yesno_place",
        text: "Luce is a beloved Italian spot in Northeast Portland — housemade pasta, excellent wine list, neighborhood gem energy. Does that sound like a good dinner night?",
        place: { name: "Luce", category: "restaurant", icon: "🍝" }
      },
      {
        id: "w3q4",
        type: "yesno_place",
        text: "Güero is a modern Mexican spot on Division Street with wood-fired meats and really good margaritas. Does that make the list?",
        place: { name: "Güero", category: "restaurant", icon: "🌮" }
      },
      {
        id: "w3q5",
        type: "scale",
        text: "How adventurous are you with food? (1 = I like what I know, 5 = I'll try anything once)",
        scale: { min: 1, max: 5, labels: ["Stick to favorites", "Try anything"] }
      }
    ]
  },

  // ── WEEK 4 ── Drinks & Nightlife ─────────────────────────
  {
    week: 4,
    theme: "Drinks & Evening Vibes",
    intro: "Portland has a serious craft beer, natural wine, and cocktail scene. And evenings here can go a lot of different directions — let's find yours.",
    questions: [
      {
        id: "w4q1",
        type: "choice",
        text: "What's your ideal evening drink situation?",
        options: [
          { value: "craft_beer", label: "Craft beer at a cool brewery" },
          { value: "cocktails", label: "Craft cocktails at a moody bar" },
          { value: "wine", label: "Wine bar with good snacks" },
          { value: "nonalcoholic", label: "Great nonalcoholic options / mocktails" },
          { value: "whatever", label: "Whatever — I just like the vibe" }
        ]
      },
      {
        id: "w4q2",
        type: "yesno_place",
        text: "Cascade Brewing Barrel House specializes in sour ales — complex, fruity, not typical beer. It's a Portland original. Worth trying even if sours are new to you?",
        place: { name: "Cascade Brewing Barrel House", category: "bar", icon: "🍻" }
      },
      {
        id: "w4q3",
        type: "yesno_place",
        text: "Pepe Le Moko is a hidden cocktail bar tucked under the Ace Hotel — dark, intimate, excellent drinks. The kind of place you feel like you discovered a secret. Does that sound like your scene?",
        place: { name: "Pepe Le Moko", category: "bar", icon: "🍸" }
      },
      {
        id: "w4q4",
        type: "scale",
        text: "How late do you like your evenings to run on vacation? (1 = In by 9pm, 5 = Close the place down)",
        scale: { min: 1, max: 5, labels: ["Early nights", "Night owl"] }
      },
      {
        id: "w4q5",
        type: "yesno_place",
        text: "Seeing a movie at the historic Bagdad Theater — a 1927 McMenamins theater where you can order beer and food in your seat — does that sound like a fun evening?",
        place: { name: "Bagdad Theater (McMenamins)", category: "entertainment", icon: "🎬" }
      }
    ]
  },

  // ── WEEK 5 ── Nature & Outdoor Activity Level ────────────
  {
    week: 5,
    theme: "Getting Outside",
    intro: "The Pacific Northwest is embarrassingly beautiful. Let's figure out how much nature you want — and how much effort you're up for.",
    questions: [
      {
        id: "w5q1",
        type: "scale",
        text: "How much physical activity feels right on a vacation day? (1 = Light walks only, 5 = I'm up for a real hike)",
        scale: { min: 1, max: 5, labels: ["Easy strolls", "Bring on the trail"] }
      },
      {
        id: "w5q2",
        type: "yesno_place",
        text: "Forest Park is one of the largest urban forests in the US — hundreds of miles of trails right inside Portland. A morning walk among giant Douglas firs sounds good?",
        place: { name: "Forest Park", category: "nature", icon: "🌲" }
      },
      {
        id: "w5q3",
        type: "yesno_place",
        text: "The Columbia River Gorge Scenic Highway is a gorgeous drive with multiple waterfall pulloffs — you can do as little or as much hiking as you want. Does a scenic drive/waterfall day sound perfect?",
        place: { name: "Columbia River Gorge Scenic Highway", category: "nature", icon: "🚗" }
      },
      {
        id: "w5q4",
        type: "yesno_place",
        text: "Oxbow Regional Park is a wild stretch of the Sandy River — great for swimming, kayaking, or just sitting by the water. Low-key nature day — does that appeal?",
        place: { name: "Oxbow Regional Park", category: "nature", icon: "🏞️" }
      },
      {
        id: "w5q5",
        type: "choice",
        text: "Which nature setting speaks to you most?",
        options: [
          { value: "forest", label: "Deep forest — tall trees, mossy trails, quiet" },
          { value: "coast", label: "Ocean — waves, sea air, dramatic cliffs" },
          { value: "mountain", label: "Mountain — elevation, views, alpine meadows" },
          { value: "river", label: "River — swimming holes, kayaking, sandy banks" }
        ]
      }
    ]
  },

  // ── WEEK 6 ── Culture, Arts & Unique Experiences ─────────
  {
    week: 6,
    theme: "Culture & Unique Only-in-Portland Things",
    intro: "Portland has some genuinely one-of-a-kind experiences. Let's see which ones land for you.",
    questions: [
      {
        id: "w6q1",
        type: "yesno_place",
        text: "The Portland Japanese Garden is considered one of the most authentic Japanese gardens outside of Japan — stunning in September when the maples start to turn. Does that sound beautiful?",
        place: { name: "Portland Japanese Garden", category: "culture", icon: "🌿" }
      },
      {
        id: "w6q2",
        type: "yesno_place",
        text: "The Oregon Museum of Science and Industry (OMSI) has cool interactive exhibits and occasionally hosts a real WWII submarine tour on the river. Museum person?",
        place: { name: "OMSI", category: "culture", icon: "🔬" }
      },
      {
        id: "w6q3",
        type: "yesno_place",
        text: "Lan Su Chinese Garden is a hidden gem — a walled Ming Dynasty-style garden in the middle of Chinatown with a tea house inside. Peaceful and unexpected. Sound like your thing?",
        place: { name: "Lan Su Chinese Garden", category: "culture", icon: "🏯" }
      },
      {
        id: "w6q4",
        type: "yesno_place",
        text: "McMenamins Kennedy School is a former elementary school turned hotel/restaurant/brewery/soaking pool. You can eat in the old classrooms, drink in the detention bar, and soak in the outdoor hot soaking pool. Unique enough?",
        place: { name: "Kennedy School Soaking Pool (McMenamins)", category: "unique", icon: "♨️" }
      },
      {
        id: "w6q5",
        type: "scale",
        text: "How much do you enjoy learning about local history and culture when you travel? (1 = Not really my thing, 5 = I love diving deep into a place)",
        scale: { min: 1, max: 5, labels: ["Skip the history", "Tell me everything"] }
      }
    ]
  },

  // ── WEEK 7 ── Shopping & Markets ─────────────────────────
  {
    week: 7,
    theme: "Shopping & Browsing",
    intro: "Portland has everything from vintage shops to local makers markets to Nike's world headquarters. Let's figure out your shopping style.",
    questions: [
      {
        id: "w7q1",
        type: "scale",
        text: "How much do you enjoy shopping on vacation? (1 = Not at all, 5 = It's part of the adventure)",
        scale: { min: 1, max: 5, labels: ["Hard pass", "Let's shop"] }
      },
      {
        id: "w7q2",
        type: "yesno_place",
        text: "Portland has great vintage and consignment shopping — stores like Red Light Clothing Exchange or House of Vintage on Hawthorne. Does thrifting / vintage sound fun?",
        place: { name: "Hawthorne Vintage Shopping", category: "shopping", icon: "👗" }
      },
      {
        id: "w7q3",
        type: "yesno_place",
        text: "The Nike Employee Store is technically open to guests with a pass — discounted Nike gear in Portland, where it all started. Worth a stop if we can get a pass?",
        place: { name: "Nike Employee Store", category: "shopping", icon: "👟" }
      },
      {
        id: "w7q4",
        type: "yesno_place",
        text: "The Portland Farmers Market at PSU (Saturday mornings) is one of the best in the country — local produce, artisan food, flowers, and great people-watching. Saturday morning market?",
        place: { name: "Portland Farmers Market (PSU)", category: "market", icon: "🥬" }
      },
      {
        id: "w7q5",
        type: "choice",
        text: "What kind of shopping do you actually enjoy?",
        options: [
          { value: "local_makers", label: "Local makers, artisan goods, one-of-a-kind finds" },
          { value: "vintage", label: "Vintage and thrift" },
          { value: "food_drink", label: "Specialty food & drink shops (cheesemakers, bottle shops)" },
          { value: "retail", label: "Regular retail / brands" },
          { value: "no_shopping", label: "I'd honestly rather skip shopping entirely" }
        ]
      }
    ]
  },

  // ── WEEK 8 ── Wellness & Relaxation ──────────────────────
  {
    week: 8,
    theme: "Rest, Wellness & Recharging",
    intro: "Every good trip needs some downtime. Let's figure out what recharging looks like for you.",
    questions: [
      {
        id: "w8q1",
        type: "yesno_place",
        text: "Everett House is a Japanese-style communal soaking spa in Portland — cedar soaking tubs, salt rooms, steam rooms, quiet and restorative. Does a spa afternoon sound like exactly what you need?",
        place: { name: "Everett House Soaking Spa", category: "wellness", icon: "🛁" }
      },
      {
        id: "w8q2",
        type: "yesno_place",
        text: "Bagby Hot Springs is a 1.5-mile hike through old growth forest to rustic cedar tubs fed by natural hot springs on the Mt. Hood National Forest. It's magic — but it's a commitment. Sound worth it?",
        place: { name: "Bagby Hot Springs", category: "wellness", icon: "♨️" }
      },
      {
        id: "w8q3",
        type: "scale",
        text: "How important is a chill morning with coffee and no agenda on vacation? (1 = I want to maximize every minute, 5 = I need at least one slow morning)",
        scale: { min: 1, max: 5, labels: ["Maximize everything", "Slow mornings are sacred"] }
      },
      {
        id: "w8q4",
        type: "choice",
        text: "What does a perfect low-key afternoon look like to you?",
        options: [
          { value: "coffee_watch", label: "Good coffee shop, people-watching, no agenda" },
          { value: "park_read", label: "A park, a book, some sunshine" },
          { value: "nap_hotel", label: "Nap at the hotel, recharge for the evening" },
          { value: "explore_wander", label: "Wandering a neighborhood with no plan" },
          { value: "not_needed", label: "I don't really need downtime — keep me busy!" }
        ]
      },
      {
        id: "w8q5",
        type: "yesno_place",
        text: "World Cup Coffee & Tea in the Pearl District is a Portland original — excellent coffee, cozy space, great for lingering. A morning coffee ritual — yes?",
        place: { name: "World Cup Coffee & Tea", category: "cafe", icon: "☕" }
      }
    ]
  },

  // ── WEEK 9 ── Day Trip Deep Dive ─────────────────────────
  {
    week: 9,
    theme: "Day Trip Deep Dive",
    intro: "Based on your earlier answers, let's get specific about the day trips that might make the itinerary.",
    questions: [
      {
        id: "w9q1",
        type: "yesno_place",
        text: "If we go to the Oregon Coast, Cannon Beach has the iconic Haystack Rock — you've probably seen it in photos. It's also 10 minutes from Astoria (Goonies filming locations). Cannon Beach: yes?",
        place: { name: "Cannon Beach", category: "coast", icon: "🪨" }
      },
      {
        id: "w9q2",
        type: "yesno_place",
        text: "The Tillamook Creamery is on the way to the coast — you can tour the factory and eat fresh cheese curds and insane ice cream. Worth a stop?",
        place: { name: "Tillamook Creamery", category: "food", icon: "🧀" }
      },
      {
        id: "w9q3",
        type: "yesno_place",
        text: "Pfriem Family Brewers in Hood River has incredible beer AND a stunning view of the Columbia River and Mt. Hood. Lunch and a pint with that view — yes or no?",
        place: { name: "Pfriem Family Brewers (Hood River)", category: "restaurant", icon: "🍺" }
      },
      {
        id: "w9q4",
        type: "yesno_place",
        text: "The Fruit Loop is a 35-mile scenic drive around Hood River Valley — orchards, farm stands, lavender farms, and amazing views. September is prime harvest season. Scenic farm drive?",
        place: { name: "Hood River Fruit Loop", category: "day_trip", icon: "🍎" }
      },
      {
        id: "w9q5",
        type: "scale",
        text: "For a day trip, how do you feel about an early start to maximize the day? (1 = I need a slow morning, can't leave before 10am, 5 = Let's leave at 7am and beat the crowds)",
        scale: { min: 1, max: 5, labels: ["10am at earliest", "Early bird wins"] }
      }
    ]
  },

  // ── WEEK 10 ── Food Finale & Must-Eats ────────────────────
  {
    week: 10,
    theme: "Final Food Votes",
    intro: "Let's lock in a few more restaurant picks. These are the spots I'm most excited about for your visit.",
    questions: [
      {
        id: "w10q1",
        type: "yesno_place",
        text: "Nong's Khao Man Gai started as a single food cart and became a Portland legend — Thai poached chicken over rice with a sauce people obsess over. A must-try cart pod experience?",
        place: { name: "Nong's Khao Man Gai", category: "restaurant", icon: "🍜" }
      },
      {
        id: "w10q2",
        type: "yesno_place",
        text: "Ava Gene's is a vegetable-forward Italian restaurant that even confirmed carnivores rave about — the pastas are extraordinary. A special dinner out?",
        place: { name: "Ava Gene's", category: "restaurant", icon: "🥗" }
      },
      {
        id: "w10q3",
        type: "yesno_place",
        text: "Pine State Biscuits is the Southern comfort food answer to Portland brunch — massive biscuit sandwiches with fried chicken and gravy. A guilty-pleasure breakfast?",
        place: { name: "Pine State Biscuits", category: "restaurant", icon: "🥐" }
      },
      {
        id: "w10q4",
        type: "yesno_place",
        text: "Jake's Famous Crawfish has been serving Portland seafood since 1892 — an old-school institution with incredible fresh fish and a great happy hour bar scene. Classic Portland dinner?",
        place: { name: "Jake's Famous Crawfish", category: "restaurant", icon: "🦞" }
      },
      {
        id: "w10q5",
        type: "yesno_place",
        text: "Bullard is a Texas-style BBQ spot that opened in Portland and immediately won over skeptics — brisket, jalapeño cheddar sausage, excellent sides. BBQ night?",
        place: { name: "Bullard BBQ", category: "restaurant", icon: "🥩" }
      }
    ]
  },

  // ── WEEK 11 ── Final Preferences & Wildcards ─────────────
  {
    week: 11,
    theme: "Last Calls & Wildcards",
    intro: "Almost there! Just a few final questions to fill in any gaps and add some fun wildcards.",
    questions: [
      {
        id: "w11q1",
        type: "choice",
        text: "What's most important to you about this trip overall?",
        options: [
          { value: "reconnect", label: "Reconnecting — long meals, good conversation, no rushing" },
          { value: "explore", label: "Exploring — I want to see as much of Portland as possible" },
          { value: "adventure", label: "Adventure — I want at least one epic experience I'll never forget" },
          { value: "relax", label: "Relaxing — I'm coming to unwind and recharge" }
        ]
      },
      {
        id: "w11q2",
        type: "yesno_place",
        text: "Willamette Valley wine country is about an hour south — pinot noir, beautiful rolling vineyards, September harvest season. A winery afternoon?",
        place: { name: "Willamette Valley Wineries", category: "day_trip", icon: "🍷" }
      },
      {
        id: "w11q3",
        type: "yesno_place",
        text: "A sunset happy hour at Departure Restaurant — rooftop bar on top of The Nines hotel with a panoramic view of downtown Portland. Cocktails with a view?",
        place: { name: "Departure Restaurant Rooftop Bar", category: "bar", icon: "🌇" }
      },
      {
        id: "w11q4",
        type: "scale",
        text: "How do you feel about sharing a meal family-style (lots of dishes for the table) vs. everyone ordering their own thing?",
        scale: { min: 1, max: 5, labels: ["Own plate please", "Share everything"] }
      },
      {
        id: "w11q5",
        type: "text",
        text: "Is there anything you're really hoping to do, eat, or experience on this trip that hasn't come up yet? (Totally optional — just write whatever comes to mind!)"
      }
    ]
  }

];

// ── TRIP CONSTANTS ───────────────────────────────────────────
const TRIP_INFO = {
  arrival: "Wednesday, September 17, 2025",
  departure: "Monday, September 22, 2025",
  nights: 5,
  guests: [
    { id: "jessica", name: "Jessica", age: 43, file: "jessica.html" },
    { id: "libby", name: "Libby", age: 55, file: "libby.html" }
  ],
  host: "Sarah",
  city: "Portland, OR"
};

// ── WEEK SCHEDULE ────────────────────────────────────────────
// Week 1 goes out June 2, 2025. Final week is August 11.
const WEEK_SCHEDULE = [
  { week: 1,  sendDate: "June 2, 2025",    dueDate: "June 8, 2025"    },
  { week: 2,  sendDate: "June 9, 2025",    dueDate: "June 15, 2025"   },
  { week: 3,  sendDate: "June 16, 2025",   dueDate: "June 22, 2025"   },
  { week: 4,  sendDate: "June 23, 2025",   dueDate: "June 29, 2025"   },
  { week: 5,  sendDate: "June 30, 2025",   dueDate: "July 6, 2025"    },
  { week: 6,  sendDate: "July 7, 2025",    dueDate: "July 13, 2025"   },
  { week: 7,  sendDate: "July 14, 2025",   dueDate: "July 20, 2025"   },
  { week: 8,  sendDate: "July 21, 2025",   dueDate: "July 27, 2025"   },
  { week: 9,  sendDate: "July 28, 2025",   dueDate: "August 3, 2025"  },
  { week: 10, sendDate: "August 4, 2025",  dueDate: "August 10, 2025" },
  { week: 11, sendDate: "August 11, 2025", dueDate: "August 17, 2025" }
];

// Export for use across pages
if (typeof module !== 'undefined') {
  module.exports = { QUESTIONS, TRIP_INFO, WEEK_SCHEDULE };
}
