# Portland Trip Planner 🌲

A multi-page GitHub Pages app for planning Sarah's Portland trip with Jessica and Libby, September 17–22, 2025.

## Setup

### 1. Create the GitHub repository

1. Create a new GitHub repo — suggested name: `portland-trip-2025`
2. Make it **public** (required for free GitHub Pages)
3. Upload all files in this folder to the repo root

### 2. Enable GitHub Pages

1. Go to repo **Settings → Pages**
2. Source: **Deploy from a branch**
3. Branch: `main`, folder: `/ (root)`
4. Save — your site will be live at `https://YOUR-USERNAME.github.io/portland-trip-2025/`

### 3. Set your admin PIN

1. Open `https://YOUR-USERNAME.github.io/portland-trip-2025/admin.html`
2. You'll be prompted to set a 4-digit PIN on first visit
3. This PIN is stored in your browser's localStorage — remember it!

### 4. Send links each Monday

From the admin panel, copy links and text them:
- **Jessica's link:** `.../jessica.html`
- **Libby's link:** `.../libby.html`
- **Tracker (both can see):** `.../tracker.html`

---

## Files

| File | Purpose |
|------|---------|
| `index.html` | Homepage with links to all pages |
| `jessica.html` | Jessica's personalized weekly survey |
| `libby.html` | Libby's personalized weekly survey |
| `tracker.html` | Shared tracker — in the running list + progress |
| `admin.html` | Sarah's admin panel (PIN protected) |
| `agenda.html` | Generated itinerary (AI-powered) |
| `questions.js` | All 11 weeks of survey questions |
| `data.js` | localStorage read/write module |

---

## Weekly Schedule

| Week | Send Date | Theme |
|------|-----------|-------|
| 1 | June 2 | Big Adventures (front-loaded travel questions) |
| 2 | June 9 | Portland's Personality |
| 3 | June 16 | Food Preferences |
| 4 | June 23 | Drinks & Evening Vibes |
| 5 | June 30 | Getting Outside |
| 6 | July 7 | Culture & Unique Experiences |
| 7 | July 14 | Shopping & Markets |
| 8 | July 21 | Rest & Wellness |
| 9 | July 28 | Day Trip Deep Dive |
| 10 | August 4 | Final Food Votes |
| 11 | August 11 | Last Calls & Wildcards |

---

## Generating the Itinerary

1. Wait until mid-August (enough data collected)
2. Open `admin.html`, enter PIN
3. Scroll to "Generate the Portland Itinerary" and click the button
4. The AI reads all survey answers and builds a day-by-day agenda
5. Tap any activity block to edit it
6. Use "Copy Text" to paste into a message or doc
7. Share `agenda.html` URL with Jessica and Libby

---

## Google Sheets Export

1. Open `admin.html`
2. Click "Generate Export" under Google Sheets Export
3. Copy the tab-separated text
4. Open your Google Sheet (Cengage Survey tab)
5. Click cell A1 and paste

---

## Adding Custom Questions

In the admin panel, scroll to "Add a Custom Question." You can add yes/no place questions to any week. These are stored in localStorage and appear alongside the pre-set questions.

---

## Technical Notes

- **All data is stored in the browser's localStorage** on each user's device. This means:
  - Jessica's answers are on Jessica's device
  - Libby's answers are on Libby's device
  - Sarah sees everyone's answers only via the Sheets export
- **No server required** — pure static site
- The AI agenda generation uses the Anthropic API (claude-sonnet-4-20250514)
- The agenda input is assembled from localStorage and passed as a prompt context

---

## Data Privacy

- Jessica and Libby can only see the **combined** "in the running" list — no individual attribution
- Only Sarah (via PIN) can see all individual answers
- The tracker shows progress (weeks complete) but not individual answers
